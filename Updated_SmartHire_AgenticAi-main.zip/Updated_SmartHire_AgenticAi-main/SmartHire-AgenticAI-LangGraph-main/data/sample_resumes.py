# This file is no longer needed as we're using real resume data
# Real resume files are located in data/resume/ directory