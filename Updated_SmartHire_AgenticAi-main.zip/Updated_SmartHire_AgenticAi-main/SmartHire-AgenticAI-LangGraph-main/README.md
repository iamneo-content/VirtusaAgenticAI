# 🤖 SmartHire - Agentic AI Interview System

An intelligent hiring platform powered by **LangGraph multi-agent workflow** that orchestrates specialized AI agents for comprehensive candidate evaluation using **real resume data**.

## 🎯 Key Features

### 🔄 **Multi-Agent Workflow**
- **Resume Parser Agent**: Extracts structured data using Gemini AI
- **Experience Predictor Agent**: ML-based experience level estimation  
- **Resume Scorer Agent**: ML-based resume quality scoring
- **Job Fit Analyzer Agent**: AI-powered compatibility assessment
- **Question Generator Agent**: Creates personalized interview questions
- **Answer Evaluator Agent**: Scores responses with detailed feedback

### 🧠 **Intelligent Orchestration**
- **State Management**: Centralized candidate data flow
- **Conditional Routing**: Dynamic workflow based on analysis results
- **Error Handling**: Automatic fallbacks and retry mechanisms
- **Real Data Processing**: Works with actual PDF resumes and training datasets

## 🚀 Quick Start

### 1. Setup Environment
```bash
git clone https://github.com/Amruth22/SmartHire-AgenticAI-LangGraph.git
cd SmartHire-AgenticAI-LangGraph

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r installation.txt
```

### 2. Configure API Keys
```bash
# Copy environment template
cp .env.example .env

# Edit .env with your Gemini API keys
GEMINI_API_KEY_1=your_api_key_here
GEMINI_API_KEY_2=your_api_key_here
GEMINI_API_KEY_3=your_api_key_here
GEMINI_API_KEY_4=your_api_key_here
```

### 3. Train ML Models (Important!)
```bash
# Pre-train the ML models before running the app
python ml/training/train_models.py
```

> Note: ML components are organized in the `ml/` folder. See [ML Module Documentation](./ml/README.md) for details.

### 4. Run Application
```bash
streamlit run main.py
```

## 📊 Available Test Data

### **Real Resume Categories**:
- **Data Engineer**: 5 candidates (Abhishek_Maurya, Jebakumar_Selvaraj, KOKILA_R, Sundhareswaran_Subramani, Tamilarasi_Ravichandran)
- **Software Developer**: 5 candidates (Aashik, Akhil_K_S, Gokul-J, Hari_Prashath, Ponmani_B)
- **Software Engineer**: 2 candidates (Gokul_Chakkarvarthi, Rajeswari__Raju)
- **Test Engineer**: 3 candidates (DIVYA_M, Tamil_Maran, Tulasimaniv)

### **Job Roles Available**:
- Software Engineer, Data Engineer, Test Engineer, Frontend Developer, DevOps Engineer, Data Scientist, Product Manager, Junior Developer

## 🏗️ Architecture

### **LangGraph Workflow**
```
START → Resume Parser → Experience Predictor → Resume Scorer → Job Fit Analyzer → Question Generator → [USER INPUT] → Answer Evaluator → END
```

### **State Schema**
```python
class CandidateState(TypedDict):
    # Input
    resume_text: str
    job_description: str
    job_title: str
    
    # Processed Data
    resume_features: Dict
    experience_level: str
    resume_score: float
    job_fit: Dict
    questions: List[Dict]
    answers: List[Dict]
    
    # Results
    final_score: float
    current_step: str
    errors: List[str]
```

## 🔧 Agent Details

### **Resume Parser Agent** (`agents/resume_parser.py`)
- Extracts structured features from PDF resumes
- Uses Gemini AI for intelligent parsing
- Handles malformed text and edge cases

### **Experience Predictor Agent** (`ml/agents/experience_predictor.py`)
- ML model trained on experience level dataset
- Rule-based fallback system
- Considers skills, projects, and leadership experience

### **Resume Scorer Agent** (`ml/agents/resume_scorer.py`)
- ML model for resume quality scoring (0-10)
- Trained on resume scoring dataset
- Evaluates experience, skills, projects, certifications

### **Job Fit Analyzer Agent** (`agents/job_fit_analyzer.py`)
- AI-powered compatibility assessment
- Generates fit scores and reasoning
- Compares candidate profile with job requirements

### **Question Generator Agent** (`agents/question_generator.py`)
- Creates personalized interview questions
- Balances concept and coding questions
- Adapts difficulty based on experience level

### **Answer Evaluator Agent** (`agents/answer_evaluator.py`)
- Dual evaluation system:
  - **Concept Questions**: SBERT semantic similarity
  - **Code Questions**: Gemini AI assessment
- Provides detailed feedback and scoring

## 📊 Usage Workflow

### **Step 1: Resume Analysis**
1. Select designation from dropdown (Data Engineer, Software Developer, etc.)
2. Choose candidate resume from available PDFs
3. Select target job role
4. AI agents automatically process and analyze

### **Step 2: Interview Session**
1. Review AI-generated personalized questions
2. Submit answers for each question
3. Get immediate evaluation and feedback

### **Step 3: Results & Export**
1. View comprehensive scoring breakdown
2. Review detailed feedback for each answer
3. Export results for record-keeping

## 🛠️ Technical Stack

- **LangGraph**: Multi-agent workflow orchestration
- **Streamlit**: Interactive web interface
- **Google Gemini AI**: Natural language processing
- **Sentence Transformers**: Semantic similarity
- **PyMuPDF**: PDF text extraction
- **Scikit-learn**: Machine learning models
- **Pandas**: Data manipulation

## 📁 Project Structure

```
SmartHire-AgenticAI-LangGraph/
├── ml/                    # Machine Learning Module
│   ├── agents/           # ML prediction agents
│   │   ├── experience_predictor.py
│   │   └── resume_scorer.py
│   ├── training/         # Training utilities and scripts
│   │   ├── train_models.py
│   │   ├── experience_level_estimator.py
│   │   └── resume_score_predictor.py
│   ├── data/             # Training datasets
│   │   ├── experience_level_training_dataset.csv
│   │   ├── resume_score_training_dataset.csv
│   │   └── resume_fit_training_dataset.csv
│   ├── models/           # Trained ML models (auto-generated)
│   ├── __init__.py
│   └── README.md         # ML Module documentation
│
├── agents/                # Non-ML AI agents
│   ├── resume_parser.py
│   ├── job_fit_analyzer.py
│   ├── question_generator.py
│   └── answer_evaluator.py
│
├── data/                  # Application data
│   ├── resume/           # PDF resume files by category
│   ├── job_descriptions.csv
│   └── sample_resumes.py
│
├── main.py                # Streamlit application
├── workflow.py            # LangGraph workflow definition
├── state.py               # State schema
├── workflow_runner.py      # Workflow execution wrapper
├── utils/                 # Utility functions
│   └── pdf_extractor.py
├── tests.py               # Unit tests
├── installation.txt       # Dependencies
└── .env.example          # Environment template
```

> **Note**: ML components are now organized in the `ml/` folder to separate machine learning functionality from the core application logic. See [ML Module README](./ml/README.md) for details.

## 🔄 Workflow Benefits

### **vs Traditional Pipeline**
- ✅ **Better Error Handling**: Individual agent failures don't crash entire system
- ✅ **State Persistence**: Resume interrupted sessions
- ✅ **Conditional Logic**: Dynamic routing based on analysis results
- ✅ **Scalability**: Easy to add new agents or modify workflow
- ✅ **Observability**: Track each step of the process

### **Multi-Agent Advantages**
- **Specialized Expertise**: Each agent focuses on specific tasks
- **Parallel Processing**: Multiple agents can work simultaneously
- **Fault Tolerance**: Individual agent failures are isolated
- **Easy Maintenance**: Modify individual agents without affecting others

## 🚀 Advanced Features

### **Dynamic Question Generation**
- Questions adapt based on:
  - Candidate experience level
  - Job fit assessment results
  - Identified skill gaps
  - Role-specific requirements

### **Intelligent Evaluation**
- **Concept Questions**: Semantic similarity using SBERT
- **Code Questions**: Logic and syntax analysis using Gemini
- **Contextual Feedback**: Specific improvement suggestions

### **ML Model Training**
- **Automatic Training**: Models train from your datasets
- **Fallback Systems**: Rule-based scoring if models fail
- **Feature Engineering**: Smart handling of missing data

## 🔧 Troubleshooting

### **Common Issues**

#### 1. **Model Training Errors**
```bash
# If models fail to train, run the training script manually
python ml/training/train_models.py

# Check if datasets have correct columns
python -c "import pandas as pd; print(pd.read_csv('ml/data/experience_level_training_dataset.csv').columns)"
```

#### 2. **PDF Extraction Issues**
```bash
# Ensure PDF files are readable
# Try with different PDF files if extraction fails
```

#### 3. **API Key Errors**
```bash
# Verify .env file exists and has correct keys
cat .env
```

## 📈 Performance

- **Processing Time**: ~30-60 seconds for complete analysis
- **Accuracy**: High-quality results through specialized agents
- **Scalability**: Handles multiple candidates efficiently
- **Reliability**: Robust error handling and fallback systems

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Implement changes with proper testing
4. Submit pull request

---

**Built with LangGraph Multi-Agent Architecture** 🤖✨

*Ready to revolutionize your hiring process with AI!*